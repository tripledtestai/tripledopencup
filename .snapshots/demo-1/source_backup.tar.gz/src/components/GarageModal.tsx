import React, { useEffect, useRef, useState } from 'react';
import { Check, Sparkles, Star, X } from 'lucide-react';
import { ALL_PARTS, SLOT_LABELS, TIER_COLORS } from '../game/constants';
import { drawModularCar } from '../game/carRenderer';
import { calculateCarClass } from '../game/rules';
import { CarLoadout, PartItem, PartSlot, StudentAccount } from '../game/types';
import { soundEngine } from '../services/sound';
import { PartThumbnail } from './PartThumbnail';

const StarRow: React.FC<{ count: number; total?: number }> = ({
  count,
  total = 5,
}) => (
  <span className="inline-flex items-center gap-0.5 text-[#FACC15]">
    {Array.from({ length: total }).map((_, i) => (
      <Star
        key={i}
        className={`w-3 h-3 ${
          i < count ? 'fill-[#FACC15] text-[#FACC15]' : 'text-[#64748B]'
        }`}
      />
    ))}
  </span>
);

interface GarageModalProps {
  student: StudentAccount;
  isTeacher?: boolean;
  onUpdateStudent: (updated: StudentAccount) => void;
  onOpenGacha: () => void;
  onClose: () => void;
}

export const GarageModal: React.FC<GarageModalProps> = ({
  student,
  isTeacher = false,
  onUpdateStudent,
  onOpenGacha,
  onClose,
}) => {
  const [activeSlot, setActiveSlot] = useState<PartSlot>('chassis');
  const [previewLoadout, setPreviewLoadout] = useState<CarLoadout>(
    student.loadout
  );
  const [feedback, setFeedback] = useState<string | null>(null);
  const previewCanvasRef = useRef<HTMLCanvasElement | null>(null);

  useEffect(() => {
    setPreviewLoadout(student.loadout);
  }, [student.loadout]);

  // High-DPI Live Spinning Turntable Preview of the Car
  useEffect(() => {
    const canvas = previewCanvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const w = 280;
    const h = 230;
    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    canvas.width = Math.floor(w * dpr);
    canvas.height = Math.floor(h * dpr);

    let animId = 0;
    const render = (now: number) => {
      animId = requestAnimationFrame(render);
      const nowSec = now / 1000;

      ctx.save();
      ctx.setTransform(1, 0, 0, 1, 0, 0);
      ctx.scale(dpr, dpr);

      // Decorative Showroom Spotlight Backdrop
      const bgGrad = ctx.createRadialGradient(
        w * 0.5,
        h * 0.5,
        12,
        w * 0.5,
        h * 0.5,
        150
      );
      bgGrad.addColorStop(0, '#2B4228');
      bgGrad.addColorStop(0.6, '#172216');
      bgGrad.addColorStop(1, '#0F1710');
      ctx.fillStyle = bgGrad;
      ctx.fillRect(0, 0, w, h);

      // Glowing Turntable Rings
      ctx.save();
      ctx.translate(w / 2, h / 2);
      ctx.rotate(nowSec * 0.4);
      ctx.strokeStyle = '#F59E0B';
      ctx.lineWidth = 2.5;
      ctx.setLineDash([16, 10]);
      ctx.beginPath();
      ctx.arc(0, 0, 82, 0, Math.PI * 2);
      ctx.stroke();

      ctx.rotate(-nowSec * 0.8);
      ctx.strokeStyle = 'rgba(74, 222, 128, 0.45)';
      ctx.lineWidth = 2;
      ctx.setLineDash([8, 8]);
      ctx.beginPath();
      ctx.arc(0, 0, 66, 0, Math.PI * 2);
      ctx.stroke();
      ctx.restore();

      drawModularCar(ctx, previewLoadout, {
        x: w / 2,
        y: h / 2,
        angle: nowSec * 0.85,
        scale: 2.35,
        nowSec,
        drifting: true,
        nitroActive: true,
      });

      ctx.restore();
    };
    animId = requestAnimationFrame(render);
    return () => cancelAnimationFrame(animId);
  }, [previewLoadout]);

  const slotItems = ALL_PARTS.filter((p) => p.slot === activeSlot);

  const handleSelectOrBuy = (item: PartItem) => {
    const isOwned = student.ownedParts.includes(item.id);
    if (isOwned) {
      const nextLoadout: CarLoadout = {
        ...student.loadout,
        [item.slot]: item.id,
      };
      setPreviewLoadout(nextLoadout);
      onUpdateStudent({
        ...student,
        loadout: nextLoadout,
      });
      soundEngine.playCoin();
      setFeedback(`✓ Đã trang bị: ${item.name}`);
      return;
    }

    if (item.gachaOnly) {
      setPreviewLoadout({
        ...previewLoadout,
        [item.slot]: item.id,
      });
      setFeedback(
        `🎁 "${item.name}" (Bậc ${item.tier}) mở tại Cầu Nguyện Gacha! (Đang xem thử trên xe)`
      );
      return;
    }

    if (student.coins < item.price) {
      setPreviewLoadout({
        ...previewLoadout,
        [item.slot]: item.id,
      });
      setFeedback(
        `⚠️ Cần ${item.price} Xu (Hiện có ${student.coins} Xu). Đang xem thử trên bàn xoay!`
      );
      return;
    }

    const nextOwned = [...student.ownedParts, item.id];
    const nextLoadout: CarLoadout = {
      ...student.loadout,
      [item.slot]: item.id,
    };
    setPreviewLoadout(nextLoadout);
    onUpdateStudent({
      ...student,
      coins: student.coins - item.price,
      ownedParts: nextOwned,
      loadout: nextLoadout,
    });
    soundEngine.playFanfare(item.tier === 'S' || item.tier === 'SS');
    setFeedback(`🎉 Mua & gắn thành công: ${item.name}!`);
  };

  return (
    <div className="fixed inset-0 z-40 flex items-center justify-center bg-black/80 p-4 select-none">
      <div className="w-full max-w-6xl max-h-[92vh] flex flex-col rounded-3xl bg-[#1E261D] border-2 border-[#F59E0B] shadow-2xl overflow-hidden">
        {/* Decorative Shop Banner Header */}
        <div className="relative flex flex-wrap items-center justify-between gap-3 px-6 py-4 bg-gradient-to-r from-[#273824] via-[#4A6046] to-[#273824] border-b-2 border-[#7A9A75]">
          <div className="flex items-center gap-3">
            <div className="w-11 h-11 rounded-2xl bg-[#1E261D] border-2 border-[#F59E0B] flex items-center justify-center text-2xl shadow">
              🛠️
            </div>
            <div>
              <h2 className="text-xl font-black text-white tracking-wide">
                XƯỞNG ĐỘ XE 7 BỘ PHẬN & CỬA HÀNG PHỤ TÙNG
              </h2>
              <div className="flex items-center gap-2 text-xs text-[#FEF08A] font-bold">
                <span className="inline-flex items-center gap-1">
                  <Sparkles className="w-3.5 h-3.5 text-[#FEF08A]" />
                  <span>Mọi xe công bằng tốc độ gốc</span>
                </span>
                <span>·</span>
                <span className="inline-flex items-center gap-1">
                  <Sparkles className="w-3.5 h-3.5 text-[#FEF08A]" />
                  <span>
                    Đã sở hữu {student.ownedParts.length}/{ALL_PARTS.length} món
                  </span>
                </span>
              </div>
            </div>
          </div>

          <div className="flex items-center gap-2.5 flex-wrap">
            <div className="px-4 py-2 rounded-xl bg-[#1E261D] border-2 border-[#F59E0B] font-mono-num text-sm font-black text-[#F59E0B]">
              🪙 {student.coins} Xu
            </div>
            {isTeacher && (
              <button
                type="button"
                onClick={() => {
                  onUpdateStudent({
                    ...student,
                    coins: student.coins + 1000,
                  });
                  soundEngine.playCoin();
                  setFeedback('⚡ Đã tự cộng +1,000 Xu cho tài khoản Giáo Viên!');
                }}
                className="px-3.5 py-2 rounded-xl bg-[#22C55E] hover:bg-[#4ADE80] text-[#0F172A] font-black text-xs shadow cursor-pointer"
              >
                ⚡ +1,000 Xu (Quyền GV)
              </button>
            )}
            <button
              type="button"
              onClick={onOpenGacha}
              className="px-4 py-2 rounded-xl bg-gradient-to-r from-[#F59E0B] to-[#D97706] hover:brightness-110 text-[#1E261D] font-black text-xs shadow-lg cursor-pointer flex items-center gap-1.5"
            >
              <Sparkles className="w-3.5 h-3.5 text-[#1E261D]" />
              <span>Cầu Nguyện Gacha</span>
            </button>
            <button
              type="button"
              onClick={onClose}
              aria-label="Đóng Xưởng Độ Xe"
              className="px-3.5 py-2 rounded-xl bg-[#1E261D] text-white border border-[#7A9A75] hover:bg-[#2E3B2C] text-xs font-bold cursor-pointer flex items-center gap-1"
            >
              <X className="w-3.5 h-3.5" />
              <span>Đóng</span>
            </button>
          </div>
        </div>

        {/* 7-Slot Category Icon Tabs */}
        <div className="flex items-center gap-2 px-6 py-3 bg-[#172016] border-b border-[#7A9A75]/50 overflow-x-auto">
          {SLOT_LABELS.map((s) => {
            const active = activeSlot === s.slot;
            return (
              <button
                key={s.slot}
                type="button"
                onClick={() => {
                  setActiveSlot(s.slot);
                  setFeedback(null);
                  soundEngine.playCoin();
                }}
                className={`px-4 py-2 rounded-xl text-xs font-extrabold whitespace-nowrap transition-all shrink-0 cursor-pointer flex items-center gap-1.5 ${
                  active
                    ? 'bg-[#F59E0B] text-[#1E261D] shadow-lg scale-105'
                    : 'bg-[#283526] text-[#E2E8F0] hover:bg-[#3A4D37] border border-[#7A9A75]/40'
                }`}
              >
                <span className="text-sm">{s.icon}</span>
                <span>{s.label}</span>
              </button>
            );
          })}
        </div>

        {/* Main Content: Left Live Turntable + Right Visual Illustrated Cards Grid */}
        <div className="flex-1 overflow-y-auto p-6 grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Left 4 Cols: 360 Turntable + Visual Equipped Badges */}
          <div className="lg:col-span-4 flex flex-col justify-between bg-[#151D14] p-4 rounded-2xl border-2 border-[#7A9A75]/70 space-y-3">
            <div className="flex flex-col items-center">
              {(() => {
                const previewClassInfo = calculateCarClass(previewLoadout);
                const previewClassStyle = TIER_COLORS[previewClassInfo.tier];
                return (
                  <div className="w-full flex items-center justify-between mb-2 px-1">
                    <div>
                      <span className="text-xs font-extrabold text-[#FEF08A] uppercase block">
                        🔄 Bàn Xoay 360°
                      </span>
                      <span className="text-[10px] text-[#A7C4A0] font-semibold">
                        Trung bình 7 phụ kiện ({previewClassInfo.averageScore.toFixed(1)}/7.0)
                      </span>
                    </div>
                    <span
                      style={{
                        backgroundColor: previewClassStyle.bg,
                        color: previewClassStyle.text,
                      }}
                      className="px-2.5 py-1 rounded-lg text-xs font-black shadow"
                    >
                      CLASS {previewClassInfo.tier}
                    </span>
                  </div>
                );
              })()}

              <canvas
                ref={previewCanvasRef}
                style={{ width: '280px', height: '230px' }}
                className="rounded-2xl border-2 border-[#7A9A75] shadow-inner block"
              />
            </div>

            {feedback && (
              <div className="p-2.5 rounded-xl bg-[#4A6046] border border-[#F59E0B] text-xs text-[#FEF08A] font-bold text-center">
                {feedback}
              </div>
            )}

            {/* Compact Visual Equipped Summary */}
            <div className="grid grid-cols-2 gap-1.5 pt-1">
              {SLOT_LABELS.map((sl) => {
                const eqId = previewLoadout[sl.slot];
                const eqItem = ALL_PARTS.find((p) => p.id === eqId);
                const tColor = eqItem
                  ? TIER_COLORS[eqItem.tier]
                  : TIER_COLORS.D;
                return (
                  <button
                    key={sl.slot}
                    type="button"
                    onClick={() => setActiveSlot(sl.slot)}
                    className={`p-2 rounded-xl bg-[#1E261D] border text-left transition-all cursor-pointer ${
                      activeSlot === sl.slot
                        ? 'border-[#F59E0B]'
                        : 'border-[#7A9A75]/40'
                    }`}
                  >
                    <div className="flex items-center justify-between text-[10px] text-[#A7C4A0]">
                      <span>
                        {sl.icon} {sl.label}
                      </span>
                      {eqItem && (
                        <span
                          style={{
                            backgroundColor: tColor.bg,
                            color: tColor.text,
                          }}
                          className="px-1.5 rounded font-black text-[9px]"
                        >
                          {eqItem.tier}
                        </span>
                      )}
                    </div>
                    <div className="text-[11px] font-bold text-white truncate mt-0.5">
                      {eqItem?.name || 'Mặc định'}
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Right 8 Cols: Illustrated Part Cards Grid (Visual Artwork instead of text walls!) */}
          <div className="lg:col-span-8 grid grid-cols-2 sm:grid-cols-3 gap-4 content-start">
            {slotItems.map((item) => {
              const isOwned = student.ownedParts.includes(item.id);
              const isEquipped = student.loadout[item.slot] === item.id;
              const isPreviewing = previewLoadout[item.slot] === item.id;
              const tierStyle = TIER_COLORS[item.tier];

              return (
                <div
                  key={item.id}
                  onClick={() => handleSelectOrBuy(item)}
                  style={{
                    borderColor: isEquipped
                      ? '#4ADE80'
                      : isPreviewing
                      ? '#F59E0B'
                      : tierStyle.border,
                  }}
                  className="group relative rounded-2xl bg-[#161F15] hover:bg-[#1F2C1E] border-2 p-3 flex flex-col items-center justify-between transition-all hover:-translate-y-0.5 shadow-xl cursor-pointer"
                >
                  {/* Top Badges: Tier + Star Rating */}
                  <div className="w-full flex items-center justify-between mb-2">
                    <span
                      style={{
                        backgroundColor: tierStyle.bg,
                        color: tierStyle.text,
                      }}
                      className="px-2.5 py-0.5 rounded-lg text-[11px] font-black tracking-wider shadow"
                    >
                      BẬC {item.tier}
                    </span>

                    <StarRow
                      count={
                        item.tier === 'SSS'
                          ? 5
                          : item.tier === 'SS'
                          ? 4
                          : item.tier === 'S'
                          ? 3
                          : item.tier === 'A'
                          ? 2
                          : 1
                      }
                    />
                  </div>

                  {/* Large Graphic Illustration Thumbnail of the Part */}
                  <div className="relative rounded-xl overflow-hidden border border-[#7A9A75]/50 shadow-inner">
                    <PartThumbnail
                      item={item}
                      baseLoadout={student.loadout}
                      width={176}
                      height={108}
                    />
                    {isEquipped && (
                      <span className="absolute top-1.5 right-1.5 px-2 py-0.5 rounded-md bg-[#22C55E] text-[#0F172A] text-[10px] font-black shadow">
                        ĐANG DÙNG
                      </span>
                    )}
                  </div>

                  {/* Item Name */}
                  <div className="text-sm font-extrabold text-white text-center mt-2.5 mb-2 line-clamp-1">
                    {item.name}
                  </div>

                  {/* Bottom Action Button */}
                  <button
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      handleSelectOrBuy(item);
                    }}
                    className={`w-full py-2 rounded-xl text-xs font-black transition-colors cursor-pointer flex items-center justify-center gap-1.5 ${
                      isEquipped
                        ? 'bg-[#22C55E] text-[#0F172A]'
                        : isOwned
                        ? 'bg-[#4A6046] hover:bg-[#5E7A59] text-white border border-[#7A9A75]'
                        : item.gachaOnly
                        ? 'bg-gradient-to-r from-[#7C3AED] to-[#C026D3] text-white'
                        : 'bg-[#F59E0B] hover:bg-[#FBBF24] text-[#1E261D]'
                    }`}
                  >
                    {isEquipped ? (
                      <>
                        <Check className="w-3.5 h-3.5 stroke-[3]" />
                        <span>ĐANG TRANG BỊ</span>
                      </>
                    ) : isOwned ? (
                      'GẮN LÊN XE'
                    ) : item.gachaOnly ? (
                      <>
                        <Sparkles className="w-3.5 h-3.5" />
                        <span>SĂN TẠI GACHA</span>
                      </>
                    ) : (
                      `🪙 MUA: ${item.price} XU`
                    )}
                  </button>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
};
