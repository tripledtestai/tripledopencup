import React, { useEffect, useRef, useState } from 'react';
import {
  Check,
  ChevronLeft,
  ChevronRight,
  Sparkles,
  Star,
  X,
} from 'lucide-react';
import {
  ALL_PARTS,
  GACHA_PITY_THRESHOLD,
  SLOT_LABELS,
  TIER_COLORS,
} from '../game/constants';
import { drawModularCar } from '../game/carRenderer';
import { spinGachaPool } from '../game/rules';
import { CarLoadout, PartItem, StudentAccount } from '../game/types';
import { soundEngine } from '../services/sound';
import { PartThumbnail } from './PartThumbnail';

const StarRow: React.FC<{ count: number; total?: number }> = ({
  count,
  total = 5,
}) => (
  <span className="inline-flex items-center gap-0.5 text-[#FACC15]">
    {Array.from({ length: total }).map((_, i) => (
      <Star
        key={i}
        className={`w-3 h-3 ${
          i < count ? 'fill-[#FACC15] text-[#FACC15]' : 'text-[#64748B]'
        }`}
      />
    ))}
  </span>
);

interface GachaModalProps {
  student: StudentAccount;
  isTeacher?: boolean;
  onUpdateStudent: (updated: StudentAccount) => void;
  onClose: () => void;
  onOpenGarage?: () => void;
}

const GACHA_SINGLE_COST = 50;
const GACHA_FIVE_COST = 225; // 5-spin bundle (10% discount!)

interface WishBannerConfig {
  id: 'banner_project' | 'banner_poolparty' | 'banner_t1';
  tabBadge: string;
  ribbon: string;
  titleLine1: string;
  titleLine2: string;
  subtitle: string;
  accentColor: string;
  secondaryColor: string;
  ribbonBg: string;
  cardGrad: string;
  featuredName: string;
  featuredTitle: string;
  featuredLoadout: CarLoadout;
  rateUpIds: string[];
}

export const WISH_BANNERS: WishBannerConfig[] = [
  {
    id: 'banner_project',
    tabBadge: 'SIÊU PHẨM (CÔNG NGHỆ)',
    ribbon: 'Dòng Skin Công Nghệ Tương Lai',
    titleLine1: 'SIÊU PHẨM:',
    titleLine2: 'Kỷ Nguyên Cyber',
    subtitle: 'Bộ sưu tập Chiến Cơ Hologram & Giáp Quang Học Cyber',
    accentColor: '#EC4899',
    secondaryColor: '#06B6D4',
    ribbonBg: 'from-[#be185d] via-[#6d28d9] to-[#0891b2]',
    cardGrad: 'from-[#0F172A] via-[#2E1065] to-[#083344]',
    featuredName: 'SIÊU PHẨM: Chiến Xa Cyber-Vayne',
    featuredTitle: 'Chiến Cơ Hologram Công Nghệ Bậc SSS',
    featuredLoadout: {
      chassis: 'chassis_project',
      paint: 'paint_project',
      decal: 'decal_project',
      wheels: 'wheels_project',
      spoiler: 'spoiler_project',
      underglow: 'underglow_project',
      trail: 'trail_project',
    },
    rateUpIds: [
      'chassis_project',
      'spoiler_project',
      'paint_project',
      'wheels_project',
      'underglow_project',
      'trail_project',
      'decal_project',
    ],
  },
  {
    id: 'banner_poolparty',
    tabBadge: 'TIỆC BÃI BIỂN',
    ribbon: 'Chủ Đề Tiệc Bãi Biển Mùa Hè',
    titleLine1: 'Tiệc Bãi Biển',
    titleLine2: 'Sóng Nhiệt Đới',
    subtitle: 'Bộ sưu tập Thủy Phi Cơ Cá Mập, Ván Lướt Sóng & Phao Cứu Sinh',
    accentColor: '#0284C7',
    secondaryColor: '#F59E0B',
    ribbonBg: 'from-[#0284C7] via-[#06B6D4] to-[#F59E0B]',
    cardGrad: 'from-[#082F49] via-[#0369A1] to-[#0F766E]',
    featuredName: 'Chiến Xa Cá Mập Tiệc Bể Bơi',
    featuredTitle: 'Thủy Phi Cơ Đại Bác Súng Nước Bậc SSS',
    featuredLoadout: {
      chassis: 'chassis_poolparty',
      paint: 'paint_poolparty',
      decal: 'decal_poolparty',
      wheels: 'wheels_poolparty',
      spoiler: 'spoiler_poolparty',
      underglow: 'underglow_poolparty',
      trail: 'trail_poolparty',
    },
    rateUpIds: [
      'chassis_poolparty',
      'trail_poolparty',
      'paint_poolparty',
      'wheels_poolparty',
      'spoiler_poolparty',
      'underglow_poolparty',
      'decal_poolparty',
    ],
  },
  {
    id: 'banner_t1',
    tabBadge: 'CHỦ ĐỀ T1 VÔ ĐỊCH',
    ribbon: 'Chủ Đề T1 Vô Địch Thế Giới',
    titleLine1: 'Huyền Thoại T1',
    titleLine2: 'Quỷ Vương Bất Tử',
    subtitle: 'Bộ sưu tập Thần Xa T1 Đỏ Hoàng Gia, Vương Miện & Hào Quang 5 Sao',
    accentColor: '#E11D48',
    secondaryColor: '#FACC15',
    ribbonBg: 'from-[#991B1B] via-[#E11D48] to-[#CA8A04]',
    cardGrad: 'from-[#450A0A] via-[#7F1D1D] to-[#1C1917]',
    featuredName: 'Thần Xa T1 Quỷ Vương Bất Tử',
    featuredTitle: 'Hào Quang 5 Sao Vô Địch Thế Giới SSS',
    featuredLoadout: {
      chassis: 'chassis_t1',
      paint: 'paint_t1',
      decal: 'decal_t1',
      wheels: 'wheels_t1',
      spoiler: 'spoiler_t1',
      underglow: 'underglow_t1',
      trail: 'trail_t1',
    },
    rateUpIds: [
      'chassis_t1',
      'spoiler_t1',
      'decal_t1',
      'underglow_t1',
      'paint_t1',
      'wheels_t1',
      'trail_t1',
    ],
  },
];

export const GachaModal: React.FC<GachaModalProps> = ({
  student,
  isTeacher = false,
  onUpdateStudent,
  onClose,
  onOpenGarage,
}) => {
  const [bannerIdx, setBannerIdx] = useState(0);
  const [spinning, setSpinning] = useState(false);
  const [wonItems, setWonItems] = useState<PartItem[]>([]);
  const [wasPityHit, setWasPityHit] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [showPoolModal, setShowPoolModal] = useState(false);

  const heroCanvasRef = useRef<HTMLCanvasElement | null>(null);
  const activeBanner = WISH_BANNERS[bannerIdx];

  const unownedParts = ALL_PARTS.filter(
    (p) => !student.ownedParts.includes(p.id)
  );
  const pityCount = student.gachaPity || 0;

  // Render the League of Legends Theme Showcase Artwork on the Banner Card
  useEffect(() => {
    const canvas = heroCanvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const w = 520;
    const h = 340;
    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    canvas.width = Math.floor(w * dpr);
    canvas.height = Math.floor(h * dpr);

    let animId = 0;
    const render = (nowMs: number) => {
      animId = requestAnimationFrame(render);
      const nowSec = nowMs / 1000;

      ctx.save();
      ctx.setTransform(1, 0, 0, 1, 0, 0);
      ctx.scale(dpr, dpr);
      ctx.clearRect(0, 0, w, h);

      const cx = w * 0.48;
      const cy = h * 0.47;

      // 1. Theme-Specific Backdrop & Emblem
      const haloGrad = ctx.createRadialGradient(cx, cy, 12, cx, cy, 165);
      haloGrad.addColorStop(0, `${activeBanner.secondaryColor}CC`);
      haloGrad.addColorStop(0.48, `${activeBanner.accentColor}66`);
      haloGrad.addColorStop(1, 'rgba(15, 23, 42, 0)');
      ctx.fillStyle = haloGrad;
      ctx.beginPath();
      ctx.arc(cx, cy, 165, 0, Math.PI * 2);
      ctx.fill();

      if (activeBanner.id === 'banner_project') {
        // SIÊU PHẨM (PROJECT): Rotating Holographic Hexagon + Cyber Triangle Reticle
        ctx.save();
        ctx.translate(cx, cy);
        ctx.rotate(nowSec * 0.35);
        ctx.strokeStyle = '#06B6D4';
        ctx.lineWidth = 2.2;
        ctx.beginPath();
        for (let i = 0; i < 6; i++) {
          const a = (i * Math.PI) / 3;
          const hx = Math.cos(a) * 124;
          const hy = Math.sin(a) * 124;
          if (i === 0) ctx.moveTo(hx, hy);
          else ctx.lineTo(hx, hy);
        }
        ctx.closePath();
        ctx.stroke();

        // PROJECT Neon Triangle Crest
        ctx.rotate(-nowSec * 0.65);
        ctx.strokeStyle = '#EC4899';
        ctx.lineWidth = 2.5;
        ctx.beginPath();
        for (let i = 0; i < 3; i++) {
          const a = (i * Math.PI * 2) / 3 - Math.PI / 2;
          const tx = Math.cos(a) * 108;
          const ty = Math.sin(a) * 108;
          if (i === 0) ctx.moveTo(tx, ty);
          else ctx.lineTo(tx, ty);
        }
        ctx.closePath();
        ctx.stroke();
        ctx.restore();
      } else if (activeBanner.id === 'banner_poolparty') {
        // TIỆC BÃI BIỂN (Pool Party): Ocean Wave Ripples, Lifebuoy & Floating Bubbles
        ctx.save();
        ctx.translate(cx, cy);
        ctx.strokeStyle = 'rgba(186, 230, 253, 0.65)';
        ctx.lineWidth = 2;
        ctx.setLineDash([14, 8]);
        ctx.rotate(nowSec * 0.25);
        ctx.beginPath();
        ctx.arc(0, 0, 125, 0, Math.PI * 2);
        ctx.stroke();

        ctx.setLineDash([]);
        ctx.strokeStyle = '#FDE047';
        ctx.lineWidth = 2.2;
        ctx.beginPath();
        ctx.arc(0, 0, 98, 0, Math.PI * 2);
        ctx.stroke();
        ctx.restore();

        // Floating tropical water bubbles
        for (let i = 0; i < 8; i++) {
          const a = nowSec * 0.9 + (i * Math.PI) / 4;
          const bx = cx + Math.cos(a) * (105 + (i % 3) * 16);
          const by = cy + Math.sin(a * 1.3) * 85;
          ctx.fillStyle = i % 2 === 0 ? 'rgba(125, 211, 252, 0.55)' : 'rgba(253, 224, 71, 0.55)';
          ctx.strokeStyle = '#FFFFFF';
          ctx.lineWidth = 1.2;
          ctx.beginPath();
          ctx.arc(bx, by, 7 + (i % 3) * 3, 0, Math.PI * 2);
          ctx.fill();
          ctx.stroke();
        }
      } else {
        // T1 VÔ ĐỊCH CKTG: Royal T1 Crest, Golden Sunburst & 5 Orbiting Worlds Stars
        ctx.save();
        ctx.translate(cx, cy);
        ctx.strokeStyle = '#FACC15';
        ctx.lineWidth = 2.5;
        ctx.beginPath();
        ctx.arc(0, 0, 124, 0, Math.PI * 2);
        ctx.stroke();

        // T1 Winged Emblem Rays
        ctx.strokeStyle = 'rgba(254, 240, 138, 0.55)';
        ctx.lineWidth = 2;
        for (let i = 0; i < 10; i++) {
          const a = (i / 10) * Math.PI * 2 + nowSec * 0.25;
          ctx.beginPath();
          ctx.moveTo(Math.cos(a) * 88, Math.sin(a) * 88);
          ctx.lineTo(Math.cos(a) * 138, Math.sin(a) * 138);
          ctx.stroke();
        }

        // 5 Worlds Championship Golden Stars around the T1 Hypercar
        for (let i = 0; i < 5; i++) {
          const a = -Math.PI / 2 + ((i - 2) * 0.34) + Math.sin(nowSec * 1.5) * 0.05;
          const sx = Math.cos(a) * 128;
          const sy = Math.sin(a) * 128;
          ctx.fillStyle = '#FEF08A';
          ctx.beginPath();
          for (let p = 0; p < 10; p++) {
            const r = p % 2 === 0 ? 11 : 5;
            const pa = (p * Math.PI) / 5 - Math.PI / 2;
            const px = sx + Math.cos(pa) * r;
            const py = sy + Math.sin(pa) * r;
            if (p === 0) ctx.moveTo(px, py);
            else ctx.lineTo(px, py);
          }
          ctx.closePath();
          ctx.fill();
        }
        ctx.restore();
      }

      // 2. Featured SSS Super-Vehicle (Large Zoomed 2.85x Display)
      drawModularCar(ctx, activeBanner.featuredLoadout, {
        x: cx,
        y: cy,
        angle: -0.42 + Math.sin(nowSec * 1.4) * 0.14,
        scale: 2.85,
        nowSec,
        drifting: true,
        nitroActive: true,
      });

      ctx.restore();
    };

    animId = requestAnimationFrame(render);
    return () => cancelAnimationFrame(animId);
  }, [activeBanner]);

  const executeSpins = (count: number, totalCost: number) => {
    setErrorMsg(null);
    if (unownedParts.length === 0) {
      setErrorMsg('Bạn đã sở hữu trọn bộ 100% vật phẩm trong kho!');
      return;
    }
    if (student.coins < totalCost) {
      setErrorMsg(
        `Chưa đủ Xu! Cần ${totalCost} Xu (Hiện có ${student.coins} Xu).`
      );
      return;
    }

    setSpinning(true);
    setWonItems([]);
    soundEngine.playCoin();

    setTimeout(() => {
      let currentOwned = [...student.ownedParts];
      let currentPityVal = student.gachaPity || 0;
      let hitPityAny = false;
      const pulled: PartItem[] = [];

      const actualCount = Math.min(count, unownedParts.length);
      for (let i = 0; i < actualCount; i++) {
        const res = spinGachaPool(
          currentOwned,
          currentPityVal,
          Math.random,
          activeBanner.rateUpIds
        );
        if (res.item) {
          pulled.push(res.item);
          currentOwned.push(res.item.id);
          currentPityVal = res.newPity;
          if (res.isPityTriggered) hitPityAny = true;
        }
      }

      setSpinning(false);
      setWonItems(pulled);
      setWasPityHit(hitPityAny);

      const hasMythic = pulled.some(
        (it) => it.tier === 'SS' || it.tier === 'SSS'
      );
      soundEngine.playFanfare(hasMythic);

      const actualCharged =
        actualCount === count ? totalCost : actualCount * GACHA_SINGLE_COST;
      onUpdateStudent({
        ...student,
        coins: student.coins - actualCharged,
        ownedParts: currentOwned,
        gachaPity: currentPityVal,
      });
    }, 550);
  };

  const handleEquipItem = (item: PartItem) => {
    onUpdateStudent({
      ...student,
      loadout: {
        ...student.loadout,
        [item.slot]: item.id,
      },
    });
    soundEngine.playCoin();
  };

  const handleEquipBannerOwnedSet = () => {
    const nextLoadout = { ...student.loadout };
    for (const partId of activeBanner.rateUpIds) {
      if (student.ownedParts.includes(partId)) {
        const part = ALL_PARTS.find((p) => p.id === partId);
        if (part) {
          nextLoadout[part.slot] = part.id;
        }
      }
    }
    onUpdateStudent({
      ...student,
      loadout: nextLoadout,
    });
    soundEngine.playFanfare(false);
  };

  const rateUpParts = activeBanner.rateUpIds
    .map((id) => ALL_PARTS.find((p) => p.id === id))
    .filter((p): p is PartItem => Boolean(p));

  const ownedInBannerCount = rateUpParts.filter((p) =>
    student.ownedParts.includes(p.id)
  ).length;

  return (
    <div className="fixed inset-0 z-50 flex flex-col justify-between bg-gradient-to-b from-[#0F172A] via-[#1E293B] to-[#1E261D] text-white p-4 md:p-6 overflow-hidden select-none">
      {/* Celestial Starlight Background Accents */}
      <div className="pointer-events-none absolute inset-0 overflow-hidden opacity-40">
        <div className="absolute -top-24 -left-24 w-96 h-96 rounded-full bg-[#38BDF8]/30 blur-3xl" />
        <div className="absolute top-1/3 -right-24 w-96 h-96 rounded-full bg-[#F59E0B]/25 blur-3xl" />
        <div className="absolute -bottom-24 left-1/3 w-96 h-96 rounded-full bg-[#EC4899]/25 blur-3xl" />
      </div>

      {/* ===================================================================== */}
      {/* TOP BAR (Wish Header: Star Title + 3 LoL Skin Banner Tabs + Coins)    */}
      {/* ===================================================================== */}
      <div className="relative z-10 flex flex-wrap items-center justify-between gap-3 max-w-6xl w-full mx-auto">
        {/* Left: Golden 4-Point Star + Wish Title */}
        <div className="flex items-center gap-2.5">
          <div className="w-9 h-9 rounded-full bg-[#F59E0B]/20 border border-[#F59E0B] flex items-center justify-center text-[#FEF08A] shadow">
            <Sparkles className="w-4 h-4 text-[#FEF08A]" />
          </div>
          <div>
            <div className="text-base font-extrabold tracking-wide text-[#FEF08A]">
              Vòng Quay Cầu Nguyện Skin
            </div>
            <div className="text-[11px] text-[#CBD5E1]">
              3 Chủ Đề: Công Nghệ · Tiệc Bãi Biển · T1 Vô Địch
            </div>
          </div>
        </div>

        {/* Center: 3 Graphical Banner Switcher Tabs */}
        <div className="flex items-center gap-2.5 flex-wrap">
          {WISH_BANNERS.map((b, idx) => {
            const isSelected = idx === bannerIdx;
            const mainItem =
              ALL_PARTS.find((p) => p.id === b.rateUpIds[0]) || ALL_PARTS[4];
            return (
              <button
                key={b.id}
                type="button"
                onClick={() => {
                  setBannerIdx(idx);
                  setWonItems([]);
                  soundEngine.playCoin();
                }}
                className={`relative rounded-xl overflow-hidden border-2 transition-all cursor-pointer flex items-center gap-2 pr-3 ${
                  isSelected
                    ? 'border-[#FEF08A] bg-[#F59E0B]/25 scale-105 shadow-[0_0_16px_rgba(245,158,11,0.5)]'
                    : 'border-[#64748B]/60 bg-[#0F172A]/80 opacity-75 hover:opacity-100'
                }`}
              >
                <PartThumbnail
                  item={mainItem}
                  baseLoadout={b.featuredLoadout}
                  width={64}
                  height={42}
                />
                <div className="text-left">
                  <div className="text-[11px] font-extrabold text-white leading-tight">
                    {b.tabBadge}
                  </div>
                  <div className="text-[10px] font-bold text-[#FEF08A] flex items-center gap-1 mt-0.5">
                    <StarRow count={5} />
                    <span>UP!</span>
                  </div>
                </div>
              </button>
            );
          })}
        </div>

        {/* Right: Currency & Pity Counters + Close Button */}
        <div className="flex items-center gap-2.5">
          <div className="px-3.5 py-1.5 rounded-full bg-[#0F172A]/90 border border-[#7A9A75] flex items-center gap-1.5 text-xs font-mono-num font-bold">
            <Sparkles className="w-3.5 h-3.5 text-[#38BDF8]" />
            <span className="text-[#38BDF8]">Bảo Hiểm Pity:</span>
            <span className="text-[#FEF08A]">
              {pityCount}/{GACHA_PITY_THRESHOLD}
            </span>
          </div>
          <div className="px-4 py-1.5 rounded-full bg-[#0F172A]/90 border border-[#F59E0B] flex items-center gap-2 text-sm font-mono-num font-extrabold text-[#F59E0B]">
            <span>🪙</span>
            <span>{student.coins} Xu</span>
          </div>
          {isTeacher && (
            <button
              type="button"
              onClick={() => {
                onUpdateStudent({
                  ...student,
                  coins: student.coins + 1000,
                });
                soundEngine.playCoin();
              }}
              className="px-3 py-1.5 rounded-full bg-[#22C55E] hover:bg-[#4ADE80] text-[#0F172A] font-black text-xs shadow cursor-pointer"
            >
              ⚡ +1,000 Xu (GV)
            </button>
          )}
          <button
            type="button"
            onClick={onClose}
            aria-label="Đóng Vòng Quay Gacha"
            className="w-9 h-9 p-0 leading-none rounded-full bg-[#E2E8F0] hover:bg-white text-[#0F172A] font-black text-sm flex items-center justify-center shadow-lg cursor-pointer shrink-0"
          >
            <X className="w-4 h-4 stroke-[3] block shrink-0" />
          </button>
        </div>
      </div>

      {/* ===================================================================== */}
      {/* CENTER HERO WISH BANNER CARD                                          */}
      {/* ===================================================================== */}
      <div className="relative z-10 max-w-6xl w-full mx-auto my-auto flex items-center gap-3">
        {/* Left Carousel Arrow */}
        <button
          type="button"
          aria-label="Banner trước"
          onClick={() =>
            setBannerIdx(
              (i) => (i - 1 + WISH_BANNERS.length) % WISH_BANNERS.length
            )
          }
          className="hidden sm:flex w-10 h-10 p-0 leading-none rounded-full bg-white/15 hover:bg-white/30 border border-white/40 items-center justify-center text-white shrink-0 cursor-pointer transition-colors"
        >
          <ChevronLeft className="w-5 h-5 stroke-[2.75] block shrink-0" />
        </button>

        {/* Main Parchment / Radiant Showcase Card */}
        <div className="relative flex-1 rounded-3xl border-4 border-[#FEF08A]/90 bg-gradient-to-r from-[#F8FAFC] via-[#EEF2FF] to-[#1E1B4B] text-[#0F172A] shadow-[0_20px_60px_rgba(0,0,0,0.65)] overflow-hidden min-h-[390px] grid grid-cols-1 lg:grid-cols-12">
          {/* Top-Left Ribbon Tag */}
          <div
            className={`absolute top-4 left-0 z-20 px-5 py-1.5 rounded-r-full bg-gradient-to-r ${activeBanner.ribbonBg} text-white text-xs font-extrabold tracking-wide shadow-md flex items-center gap-1.5`}
          >
            <Sparkles className="w-3.5 h-3.5 text-[#FEF08A]" />
            <span>{activeBanner.ribbon}</span>
          </div>

          {/* LEFT 5 COLS: Banner Title, Theme Subtitle & 6 Rate-Up Skin Thumbnails */}
          <div className="lg:col-span-5 p-6 pt-14 flex flex-col justify-between relative z-10 bg-gradient-to-r from-[#F8FAFC] via-[#F1F5F9]/95 to-transparent">
            <div className="space-y-2.5">
              {/* Two-Line Hero Banner Title */}
              <div className="leading-none">
                <div className="font-display text-3xl sm:text-4xl font-black text-[#0F172A] tracking-tight">
                  {activeBanner.titleLine1}
                </div>
                <div
                  style={{ color: activeBanner.accentColor }}
                  className="font-display text-3xl sm:text-4xl font-black tracking-tight mt-1"
                >
                  {activeBanner.titleLine2}
                </div>
              </div>

              <div className="text-xs font-bold text-[#334155]">
                {activeBanner.subtitle}
              </div>

              {/* Rate-Up & Pity Guarantee Box */}
              <div
                style={{ backgroundColor: activeBanner.accentColor }}
                className="p-2.5 rounded-xl text-white text-xs font-bold shadow-md flex items-start gap-2"
              >
                <Sparkles className="w-4 h-4 text-[#FEF08A] shrink-0 mt-0.5" />
                <span>
                  Tăng tỉ lệ rơi bộ 7 món{' '}
                  <strong>{activeBanner.tabBadge}</strong>! Đạt mốc bảo hiểm Pity{' '}
                  <strong>{GACHA_PITY_THRESHOLD} lượt quay</strong> chắc chắn nổ
                  SS/SSS của Banner!
                </span>
              </div>
            </div>

            {/* Illustrated Rate-Up Mini Cards (Show top 6 parts of the LoL Skin Set) */}
            <div className="pt-3">
              <div className="flex items-center justify-between mb-1.5">
                <span className="text-[11px] font-extrabold text-[#334155] uppercase tracking-wider">
                  Bộ Skin {activeBanner.tabBadge} ({ownedInBannerCount}/
                  {rateUpParts.length} Đã Mở):
                </span>
                {ownedInBannerCount > 0 && (
                  <button
                    type="button"
                    onClick={handleEquipBannerOwnedSet}
                    className="px-2.5 py-0.5 rounded-lg bg-[#0F172A] hover:bg-[#1E293B] text-[#FEF08A] text-[10px] font-black cursor-pointer"
                  >
                    ⚡ Trang Bị Bộ Đã Mở
                  </button>
                )}
              </div>
              <div className="grid grid-cols-3 gap-2">
                {rateUpParts.slice(0, 6).map((part) => {
                  const owned = student.ownedParts.includes(part.id);
                  return (
                    <div
                      key={part.id}
                      onClick={() => owned && handleEquipItem(part)}
                      className={`relative rounded-xl overflow-hidden border-2 bg-[#0F172A] p-1 text-center shadow ${
                        owned
                          ? 'border-[#4ADE80] cursor-pointer hover:scale-105 transition-transform'
                          : 'border-[#F59E0B]'
                      }`}
                    >
                      <span className="absolute top-1 right-1 z-10 px-1.5 py-0.5 rounded bg-[#F59E0B] text-[#0F172A] text-[8px] font-black">
                        {part.tier}
                      </span>
                      <PartThumbnail
                        item={part}
                        baseLoadout={activeBanner.featuredLoadout}
                        width={86}
                        height={50}
                        className="mx-auto"
                      />
                      <div className="text-[10px] font-extrabold text-white truncate px-1 mt-0.5">
                        {part.name}
                      </div>
                      <div className="text-[9px] font-bold text-[#FEF08A] flex items-center justify-center gap-0.5">
                        {owned ? (
                          <>
                            <Check className="w-2.5 h-2.5 text-[#4ADE80]" />
                            <span className="text-[#4ADE80]">Đã Mở</span>
                          </>
                        ) : (
                          'UP! Rơi Cao'
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>

          {/* RIGHT 7 COLS: Giant Animated Visual Showcase + Nameplate + 5 Stars */}
          <div
            className={`lg:col-span-7 relative flex items-center justify-center bg-gradient-to-br ${activeBanner.cardGrad} p-4 overflow-hidden`}
          >
            {/* Live High-DPI Canvas Artwork */}
            <canvas
              ref={heroCanvasRef}
              style={{ width: '520px', height: '340px' }}
              className="max-w-full h-auto block"
            />

            {/* Featured LoL Skin Vehicle Nameplate Overlay */}
            <div className="absolute bottom-5 left-6 right-6 flex flex-wrap items-end justify-between gap-3 pointer-events-none">
              <div className="bg-[#0F172A]/90 border-2 border-[#F59E0B] rounded-2xl px-4 py-2.5 shadow-2xl">
                <div className="flex items-center gap-2">
                  <span className="px-2 py-0.5 rounded bg-[#F59E0B] text-[#0F172A] text-[10px] font-black">
                    SKIN {activeBanner.tabBadge} · SSS
                  </span>
                  <StarRow count={5} />
                </div>
                <div className="text-lg sm:text-xl font-black text-white mt-0.5">
                  {activeBanner.featuredName}
                </div>
                <div className="text-xs font-semibold text-[#FEF08A]">
                  {activeBanner.featuredTitle}
                </div>
              </div>

              {/* Remaining Pool Badge */}
              <div className="bg-[#0F172A]/90 border border-[#7A9A75] rounded-xl px-3.5 py-2 text-right">
                <div className="text-[10px] text-[#A7C4A0] font-bold uppercase">
                  Kho Báu Còn Lại
                </div>
                <div className="font-mono-num text-sm font-black text-[#4ADE80]">
                  {unownedParts.length}/{ALL_PARTS.length} Món
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Right Carousel Arrow */}
        <button
          type="button"
          aria-label="Banner tiếp theo"
          onClick={() => setBannerIdx((i) => (i + 1) % WISH_BANNERS.length)}
          className="hidden sm:flex w-10 h-10 p-0 leading-none rounded-full bg-white/15 hover:bg-white/30 border border-white/40 items-center justify-center text-white shrink-0 cursor-pointer transition-colors"
        >
          <ChevronRight className="w-5 h-5 stroke-[2.75] block shrink-0" />
        </button>
      </div>

      {/* Error Toast if insufficient coins */}
      {errorMsg && (
        <div className="relative z-20 self-center px-5 py-2.5 rounded-xl bg-red-950/95 border-2 border-red-400 text-xs font-bold text-red-100 shadow-xl">
          ⚠️ {errorMsg}
        </div>
      )}

      {/* ===================================================================== */}
      {/* BOTTOM BAR (Left Utility Buttons + Right Cream/Gold Wish x1 & x5)     */}
      {/* ===================================================================== */}
      <div className="relative z-10 flex flex-wrap items-center justify-between gap-4 max-w-6xl w-full mx-auto">
        {/* Bottom-Left: Garage & Collection Buttons */}
        <div className="flex items-center gap-2.5">
          {onOpenGarage && (
            <button
              type="button"
              onClick={onOpenGarage}
              className="px-5 py-2.5 rounded-xl bg-[#E2E8F0] hover:bg-white text-[#1E293B] font-extrabold text-xs shadow-md cursor-pointer"
            >
              🛠️ Xưởng Độ Xe
            </button>
          )}
          <button
            type="button"
            onClick={() => setShowPoolModal(true)}
            className="px-5 py-2.5 rounded-xl bg-[#E2E8F0] hover:bg-white text-[#1E293B] font-extrabold text-xs shadow-md cursor-pointer"
          >
            📦 Xem Kho Skin & Phụ Tùng ({unownedParts.length} Chưa Mở)
          </button>
        </div>

        {/* Bottom-Right: Cream & Gold Wish x1 and Wish x5 Buttons */}
        <div className="flex items-center gap-3">
          <button
            type="button"
            disabled={spinning || unownedParts.length === 0}
            onClick={() => executeSpins(1, GACHA_SINGLE_COST)}
            className="min-w-[185px] px-6 py-2.5 rounded-2xl bg-gradient-to-b from-[#FFFBEB] to-[#FDE68A] hover:from-white hover:to-[#FCD34D] text-[#1E293B] border-2 border-[#D97706] shadow-xl transition-transform active:scale-95 disabled:opacity-50 cursor-pointer text-center"
          >
            <div className="text-sm font-black tracking-wide flex items-center justify-center gap-1.5">
              <Sparkles className="w-4 h-4 text-[#D97706]" />
              <span>Cầu Nguyện ×1</span>
            </div>
            <div className="text-xs font-mono-num font-extrabold text-[#B45309] mt-0.5">
              🪙 {GACHA_SINGLE_COST} Xu
            </div>
          </button>

          <button
            type="button"
            disabled={spinning || unownedParts.length === 0}
            onClick={() => executeSpins(5, GACHA_FIVE_COST)}
            className="min-w-[205px] px-6 py-2.5 rounded-2xl bg-gradient-to-b from-[#FEF08A] via-[#F59E0B] to-[#D97706] hover:brightness-110 text-[#0F172A] border-2 border-[#FFFBEB] shadow-xl transition-transform active:scale-95 disabled:opacity-50 cursor-pointer text-center"
          >
            <div className="text-sm font-black tracking-wide flex items-center justify-center gap-1.5">
              <Star className="w-4 h-4 fill-[#0F172A] text-[#0F172A]" />
              <span>Cầu Nguyện ×5 (Ưu Đãi)</span>
            </div>
            <div className="text-xs font-mono-num font-black text-[#1E293B] mt-0.5">
              🪙 {GACHA_FIVE_COST} Xu (Tiết kiệm 25 Xu)
            </div>
          </button>
        </div>
      </div>

      {/* ===================================================================== */}
      {/* WISH METEOR REVEAL OVERLAY WHEN ITEMS ARE PULLED                      */}
      {/* ===================================================================== */}
      {wonItems.length > 0 && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 p-4">
          <div className="w-full max-w-4xl rounded-3xl bg-gradient-to-b from-[#1E1B4B] via-[#1E261D] to-[#0F172A] border-2 border-[#FEF08A] p-6 shadow-2xl space-y-5 text-center">
            <div>
              <div className="text-xs font-extrabold text-[#FEF08A] uppercase tracking-widest flex items-center justify-center gap-1.5">
                <Sparkles className="w-4 h-4 text-[#FEF08A]" />
                <span>
                  {wasPityHit
                    ? 'NỔ BẢO HIỂM PITY CHẮC CHẮN SS/SSS!'
                    : `KẾT QUẢ CẦU NGUYỆN BANNER ${activeBanner.tabBadge}`}
                </span>
                <Sparkles className="w-4 h-4 text-[#FEF08A]" />
              </div>
              <h3 className="text-2xl font-black text-white mt-1">
                Chúc Mừng Tay Đua Nhận Được Vật Phẩm Mới!
              </h3>
            </div>

            <div
              className={`grid gap-4 justify-center ${
                wonItems.length === 1
                  ? 'grid-cols-1 max-w-xs mx-auto'
                  : 'grid-cols-2 sm:grid-cols-3 md:grid-cols-5'
              }`}
            >
              {wonItems.map((item) => {
                const tColor = TIER_COLORS[item.tier];
                const slotLabel =
                  SLOT_LABELS.find((s) => s.slot === item.slot)?.label ||
                  item.slot;
                const isEquipped = student.loadout[item.slot] === item.id;
                return (
                  <div
                    key={item.id}
                    style={{ borderColor: tColor.border }}
                    className="rounded-2xl bg-[#0F172A] border-2 p-3 flex flex-col items-center justify-between shadow-xl"
                  >
                    <div className="w-full flex items-center justify-between text-[10px] font-black mb-1">
                      <span className="text-[#CBD5E1]">{slotLabel}</span>
                      <span
                        style={{
                          backgroundColor: tColor.bg,
                          color: tColor.text,
                        }}
                        className="px-2 py-0.5 rounded"
                      >
                        Bậc {item.tier}
                      </span>
                    </div>

                    <PartThumbnail
                      item={item}
                      baseLoadout={student.loadout}
                      width={130}
                      height={90}
                      animated={wonItems.length === 1}
                    />

                    <div className="my-2 flex flex-col items-center gap-1">
                      <div className="text-xs font-extrabold text-white">
                        {item.name}
                      </div>
                      <StarRow
                        count={
                          item.tier === 'SSS'
                            ? 5
                            : item.tier === 'SS'
                            ? 4
                            : 3
                        }
                      />
                    </div>

                    <button
                      type="button"
                      onClick={() => handleEquipItem(item)}
                      className={`w-full py-1.5 rounded-xl font-extrabold text-xs cursor-pointer flex items-center justify-center gap-1 ${
                        isEquipped
                          ? 'bg-[#22C55E] text-[#0F172A]'
                          : 'bg-[#F59E0B] hover:bg-[#FBBF24] text-[#0F172A]'
                      }`}
                    >
                      {isEquipped ? (
                        <>
                          <Check className="w-3.5 h-3.5 stroke-[3]" />
                          <span>Đang Trang Bị</span>
                        </>
                      ) : (
                        'Trang Bị Ngay'
                      )}
                    </button>
                  </div>
                );
              })}
            </div>

            <div className="pt-2">
              <button
                type="button"
                onClick={() => setWonItems([])}
                className="px-8 py-2.5 rounded-xl bg-[#FEF08A] hover:bg-white text-[#0F172A] font-black text-sm shadow-lg cursor-pointer"
              >
                Xác Nhận & Tiếp Tục Cầu Nguyện
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ===================================================================== */}
      {/* VISUAL POOL GALLERY MODAL                                             */}
      {/* ===================================================================== */}
      {showPoolModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 p-4">
          <div className="w-full max-w-5xl max-h-[85vh] flex flex-col rounded-3xl bg-[#1E261D] border-2 border-[#7A9A75] overflow-hidden shadow-2xl">
            <div className="flex items-center justify-between px-6 py-4 bg-[#4A6046] border-b border-[#7A9A75]">
              <h3 className="text-lg font-extrabold text-white">
                📦 Bộ Sưu Tập Vật Phẩm Cầu Nguyện ({student.ownedParts.length}/
                {ALL_PARTS.length} Đã Sở Hữu)
              </h3>
              <button
                type="button"
                onClick={() => setShowPoolModal(false)}
                className="px-3.5 py-1.5 rounded-xl bg-[#1E261D] text-white border border-[#7A9A75] text-xs font-bold cursor-pointer flex items-center gap-1"
              >
                <X className="w-3.5 h-3.5" />
                <span>Đóng</span>
              </button>
            </div>
            <div className="p-5 overflow-y-auto grid grid-cols-2 sm:grid-cols-4 md:grid-cols-5 gap-3">
              {ALL_PARTS.map((part) => {
                const owned = student.ownedParts.includes(part.id);
                const tColor = TIER_COLORS[part.tier];
                return (
                  <div
                    key={part.id}
                    style={{ borderColor: owned ? '#4ADE80' : tColor.border }}
                    className={`rounded-2xl bg-[#141A13] border p-2.5 flex flex-col items-center text-center ${
                      owned ? 'opacity-100' : 'opacity-85'
                    }`}
                  >
                    <PartThumbnail item={part} width={110} height={72} />
                    <div className="text-xs font-extrabold text-white mt-1.5 truncate w-full">
                      {part.name}
                    </div>
                    <div className="flex items-center gap-1.5 mt-1">
                      <span
                        style={{
                          backgroundColor: tColor.bg,
                          color: tColor.text,
                        }}
                        className="px-1.5 py-0.5 rounded text-[10px] font-black"
                      >
                        {part.tier}
                      </span>
                      <span
                        className={`text-[10px] font-bold flex items-center gap-0.5 ${
                          owned ? 'text-[#4ADE80]' : 'text-[#FDE047]'
                        }`}
                      >
                        {owned ? (
                          <>
                            <Check className="w-3 h-3" />
                            <span>Đã Có</span>
                          </>
                        ) : (
                          'Chưa Mở'
                        )}
                      </span>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
